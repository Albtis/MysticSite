import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"

const privileges = [
  { name: "VIP", description: "Доступ к эксклюзивным зонам и командам", price: "500 руб/мес" },
  { name: "Premium", description: "Все преимущества VIP + уникальные предметы", price: "1000 руб/мес" },
  { name: "Elite", description: "Максимальные возможности и персональная поддержка", price: "2000 руб/мес" },
]

export default function Privileges() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Привилегии</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {privileges.map((privilege) => (
          <Card key={privilege.name}>
            <CardHeader>
              <CardTitle>{privilege.name}</CardTitle>
              <CardDescription>{privilege.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-primary">{privilege.price}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

