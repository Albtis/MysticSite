import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { name, email, message } = await req.json()
  
  // Здесь вы можете добавить логику для сохранения сообщения в базе данных
  // или отправки его на электронную почту администратора
  console.log('Получено сообщение поддержки:', { name, email, message })

  return NextResponse.json({ success: true })
}

