import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { connectToDatabase } from "@/lib/mongodb"
import Balance from "@/models/Balance"
import Purchase from "@/models/Purchase"
import { shopItems } from "@/lib/shop-items"

export async function POST(req: Request) {
  try {
    const session = await getServerSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { itemId } = await req.json()
    const item = shopItems.find(i => i.id === itemId)
    
    if (!item) {
      return NextResponse.json({ error: "Item not found" }, { status: 404 })
    }

    await connectToDatabase()
    
    const balance = await Balance.findOne({ userId: session.user.id })
    if (!balance || balance.amount < item.price) {
      return NextResponse.json({ error: "Insufficient funds" }, { status: 400 })
    }

    // Update balance
    balance.amount -= item.price
    balance.transactions.push({
      type: 'PURCHASE',
      amount: -item.price,
      description: `Покупка привилегии ${item.name}`
    })
    await balance.save()

    // Create purchase record
    await Purchase.create({
      userId: session.user.id,
      itemId: item.id,
      itemName: item.name,
      price: item.price
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

