import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import User from "@/models/User"
import bcrypt from "bcryptjs"

export async function POST(req: Request) {
  try {
    const { username, email, password } = await req.json()

    await connectToDatabase()

    // Check if user already exists
    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return NextResponse.json({ error: "Пользователь с таким email уже существует" }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create new user
    const newUser = new User({
      username,
      email,
      password: hashedPassword,
    })

    await newUser.save()

    return NextResponse.json({ message: "Пользователь успешно зарегистрирован" }, { status: 201 })
  } catch (error) {
    console.error("Error in signup:", error)
    return NextResponse.json({ error: "Ошибка при регистрации пользователя" }, { status: 500 })
  }
}

