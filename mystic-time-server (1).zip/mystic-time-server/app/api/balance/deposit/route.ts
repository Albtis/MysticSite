import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { connectToDatabase } from "@/lib/mongodb"
import Balance from "@/models/Balance"

export async function POST(req: Request) {
  try {
    const session = await getServerSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { amount } = await req.json()
    if (!amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 })
    }

    await connectToDatabase()
    
    let balance = await Balance.findOne({ userId: session.user.id })
    if (!balance) {
      balance = new Balance({ userId: session.user.id, amount: 0 })
    }

    balance.amount += amount
    balance.transactions.push({
      type: 'DEPOSIT',
      amount: amount,
      description: 'Пополнение баланса'
    })
    await balance.save()

    return NextResponse.json({ success: true, balance: balance.amount })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

