"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function Home() {
  const [isOpen, setIsOpen] = useState(false)
  const serverIP = "play.mystic-time.com" // Замените на реальный IP вашего сервера

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)]">
      <h1 className="text-4xl font-bold mb-6">Добро пожаловать на Mystic Time</h1>
      <p className="text-xl mb-8 text-center max-w-2xl">
        Погрузитесь в мир магии и приключений на нашем уникальном сервере Minecraft!
      </p>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button size="lg">Начать игру</Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Подключение к серверу</DialogTitle>
            <DialogDescription>
              Используйте следующий IP-адрес для подключения к нашему серверу:
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center p-4">
            <code className="bg-secondary p-2 rounded">{serverIP}</code>
          </div>
          <p className="text-center text-sm text-muted-foreground">
            Скопируйте этот адрес и вставьте его в поле "Адрес сервера" в вашем клиенте Minecraft.
          </p>
        </DialogContent>
      </Dialog>
    </div>
  )
}

