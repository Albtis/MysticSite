"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export default function Support() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/support', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, message }),
      })
      if (response.ok) {
        toast({
          title: "Сообщение отправлено",
          description: "Мы свяжемся с вами в ближайшее время.",
        })
        setName("")
        setEmail("")
        setMessage("")
      } else {
        throw new Error('Ошибка отправки')
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить сообщение. Попробуйте позже.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Поддержка</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-1">Имя</label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ваше имя" required />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" required />
        </div>
        <div>
          <label htmlFor="message" className="block text-sm font-medium mb-1">Сообщение</label>
          <Textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Опишите вашу проблему или вопрос" rows={5} required />
        </div>
        <Button type="submit">Отправить</Button>
      </form>
    </div>
  )
}

