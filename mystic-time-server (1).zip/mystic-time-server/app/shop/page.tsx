"use client"

import { useState } from "react"
import { useSession } from "next-auth/react"
import { shopItems } from "@/lib/shop-items"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"

export default function Shop() {
  const { data: session } = useSession()
  const [selectedItem, setSelectedItem] = useState<typeof shopItems[0] | null>(null)
  const { toast } = useToast()

  const handlePurchase = async (item: typeof shopItems[0]) => {
    if (!session) {
      toast({
        title: "Необходима авторизация",
        description: "Пожалуйста, войдите в систему для совершения покупок",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch('/api/shop/purchase', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ itemId: item.id }),
      })

      if (!response.ok) {
        throw new Error('Ошибка при покупке')
      }

      const data = await response.json()
      
      toast({
        title: "Успешная покупка!",
        description: `Вы приобрели привилегию ${item.name}`,
      })
      
      setSelectedItem(null)
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Недостаточно средств или произошла ошибка при покупке",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Магазин привилегий</h1>
        {session && (
          <Button variant="outline" onClick={() => window.location.href = '/profile'}>
            Мой баланс
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {shopItems.map((item) => (
          <Card key={item.id} className="relative overflow-hidden">
            {item.originalPrice > item.price && (
              <Badge className="absolute top-4 right-4 bg-red-500">
                Скидка {Math.round((1 - item.price / item.originalPrice) * 100)}%
              </Badge>
            )}
            <CardHeader>
              <CardTitle>{item.name}</CardTitle>
              <CardDescription>{item.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {item.features.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex items-center gap-2">
                <span className="text-2xl font-bold">{item.price}₽</span>
                {item.originalPrice > item.price && (
                  <span className="text-lg text-muted-foreground line-through">
                    {item.originalPrice}₽
                  </span>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full" onClick={() => setSelectedItem(item)}>
                    Купить
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Подтверждение покупки</DialogTitle>
                    <DialogDescription>
                      Вы собираетесь приобрести привилегию {item.name} за {item.price}₽
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p>Привилегия будет активирована автоматически после покупки.</p>
                    {!session && (
                      <p className="text-red-500">
                        Необходимо войти в систему для совершения покупки.
                      </p>
                    )}
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setSelectedItem(null)}>
                      Отмена
                    </Button>
                    <Button onClick={() => handlePurchase(item)}>
                      Подтвердить
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

