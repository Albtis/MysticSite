"use client"

import { useState } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

export default function Profile() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [depositAmount, setDepositAmount] = useState("")
  const { toast } = useToast()

  const handleDeposit = async () => {
    if (!session) return

    try {
      const amount = parseInt(depositAmount)
      if (isNaN(amount) || amount <= 0) {
        toast({
          title: "Ошибка",
          description: "Введите корректную сумму",
          variant: "destructive",
        })
        return
      }

      const response = await fetch('/api/balance/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount }),
      })

      if (!response.ok) {
        throw new Error('Ошибка пополнения')
      }

      const data = await response.json()
      toast({
        title: "Успешно!",
        description: `Баланс пополнен на ${amount}₽`,
      })
      setDepositAmount("")
      router.refresh()
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось пополнить баланс",
        variant: "destructive",
      })
    }
  }

  if (status === "loading") {
    return <div>Загрузка...</div>
  }

  if (!session) {
    router.push("/auth/signin")
    return null
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Личный кабинет</h1>
      <Card>
        <CardHeader>
          <CardTitle>Управление балансом</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Input
              type="number"
              placeholder="Сумма пополнения"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
            />
            <Button onClick={handleDeposit}>Пополнить</Button>
          </div>
          <div className="text-lg">
            Текущий баланс: <span className="font-bold">{session.user?.balance || 0}₽</span>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Информация о профиле</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium mb-1">Имя пользователя</label>
            <Input id="username" defaultValue={session.user?.name || ""} readOnly />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
            <Input id="email" type="email" defaultValue={session.user?.email || ""} readOnly />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

