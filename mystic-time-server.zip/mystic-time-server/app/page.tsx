import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)]">
      <h1 className="text-4xl font-bold mb-6">Добро пожаловать на Mystic Time</h1>
      <p className="text-xl mb-8 text-center max-w-2xl">
        Погрузитесь в мир магии и приключений на нашем уникальном сервере Minecraft!
      </p>
      <Button size="lg">Начать игру</Button>
    </div>
  )
}

