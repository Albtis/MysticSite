import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function Support() {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Поддержка</h1>
      <form className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-1">Имя</label>
          <Input id="name" placeholder="Ваше имя" />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
          <Input id="email" type="email" placeholder="your@email.com" />
        </div>
        <div>
          <label htmlFor="message" className="block text-sm font-medium mb-1">Сообщение</label>
          <Textarea id="message" placeholder="Опишите вашу проблему или вопрос" rows={5} />
        </div>
        <Button type="submit">Отправить</Button>
      </form>
    </div>
  )
}

